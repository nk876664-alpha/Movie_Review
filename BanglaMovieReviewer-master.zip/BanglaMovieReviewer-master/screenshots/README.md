# Screenshots

Application screenshots:

- `home.jpeg` - Home/Landing page
- `analyzer.jpeg` - Analyzer page with input form
- `output1.jpeg` - Results page with charts (example 1)
- `output2.jpeg` - Results page with charts (example 2)
- `history.jpeg` - Analysis history page
- `about.jpeg` - About page

These screenshots are automatically displayed in the main README.md file.
